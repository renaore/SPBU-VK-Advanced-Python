# Latex Library #

## What is this? ##
The module allows you to create latex code for tables and images


----------


## Developer ##
My site: [link](https://github.com/renaore) 